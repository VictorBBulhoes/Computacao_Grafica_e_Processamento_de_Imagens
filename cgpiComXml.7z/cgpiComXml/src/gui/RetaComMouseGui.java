package gui;

import Armazenador.ListaLigada;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Attr;

import Armazenador.No;
import Armazenador.Pilha;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import primitivos.AlgoritmosCirculos;
import primitivos.AlgoritmosRetas;
import primitivos.CirculoGr;
import primitivos.Ponto;
import primitivos.PontoGr;
import primitivos.RetaGr;
import primitivos.RetanguloGr;

public class RetaComMouseGui  {
	int x1=0, y1=0, x2=0, y2=0;
	int x=0, y=0, xant=0, yant=0;

	int divisoes; 
	int tamLado = 300;
	int tamForma =170;
	int evento = 0;
	int z = 0;
	public int nComando = 0;
	
	ListaLigada circ = new ListaLigada();
	ListaLigada pont = new ListaLigada();
	ListaLigada reta = new ListaLigada();
	ListaLigada retan = new ListaLigada();
	
	
	
	
	boolean primeiraVez = true;

	public RetaComMouseGui(Stage palco) {
		
		Stage mapa = new Stage();
		
		// N� m�ximo de elementos que o CTRL + Z suporta = 100
		Comando[] comando = new Comando[100];
		
		// define titulo da janela
		palco.setTitle("Reta e Circulo com mouse");

		// define largura e altura da janela
		palco.setWidth(800);
		palco.setHeight(600);

		// Painel para os componentes
		BorderPane pane = new BorderPane();

		// componente para desenho
		Canvas canvas = new Canvas(800, 800);
			
		
		
		// componente para desenhar graficos
		GraphicsContext gc;
		gc = canvas.getGraphicsContext2D();

		
		//desenhar quadrado
		
		//Ponto novo = new Ponto(30,70);
		
		
		//Caixa de texto com botao de leitura
		//Label label1 = new Label("Divisoes:");
		//TextField textField = new TextField ();
		HBox hb = new HBox();
		Button buttonCurrent = new Button("Mapeamento");
		Button retangulo = new Button("Ret�ngulo");
		Button ponto = new Button("Ponto");
		Button circulo = new Button("C�rculo");
		Button linha = new Button("Linha");
		Button limpa = new Button("Limpar");
		Button crz = new Button("CTRL + Z");
		Button clip = new Button("Clipping");
		Button xml = new Button("Salva XML");
		
		//tamanho botoes
		limpa.setPrefSize(103, 20);
		retangulo.setPrefSize(103, 20);
		buttonCurrent.setPrefSize(103, 20);// botao mapeamento 
		linha.setPrefSize(103, 20);//botao linha
		ponto.setPrefSize(103, 20);//botao ponto
		circulo.setPrefSize(103, 20);//botao circulo
		crz.setPrefSize(103, 20);
		clip.setPrefSize(103, 20);
		xml.setPrefSize(103, 20);
		
		buttonCurrent.setOnAction(event->{
			
			// Controi o canvas pequeno !!
			new Mapa(mapa,circ,reta,retan);
			
		});
		
		crz.setOnAction(event->{
			
			
			
		});
		
		
		ponto.setOnAction(event->{
			//Desenhar retangulo
			
			evento = 5;
			
		});
		
		
		circulo.setOnAction(event->{
			
			evento = 1;
			
		});
		
		
		linha.setOnAction(event->{
			//Desenhar retangulo
			
			evento = 2;
			
		});
		
		retangulo.setOnAction(event->{
			//Desenhar retangulo
			
			evento = 3;
			
		});
		
		
		limpa.setOnAction(event->{
			
            gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
            circ = null;
            circ = new ListaLigada( );
            pont = null;
            pont = new ListaLigada( );
            reta = null;
            reta = new ListaLigada( );
            retan = null;
            retan = new ListaLigada( );
		});
		
		clip.setOnAction(event->{
			
			evento = 6;
			
		});
		
		crz.setOnAction(event->{
			//CTRL + Z
			evento = 7;
		});
		
		xml.setOnAction(event->{
			//Salva em XML
			evento = 8;
		});
		
		
		hb.getChildren( ).addAll( ponto, linha, circulo, retangulo, limpa, buttonCurrent, crz, clip, xml );
		hb.setSpacing( 10 );
		
		pane.setTop(hb);
		
		// Eventos de mouse
		// trata mouseMoved
		canvas.setOnMouseMoved(event -> {
			palco.setTitle("(BotaoEsq - desenha reta) (BotaoDir - desenha circulo) (BotaoMeio - limpa canvas)"+" (" + (int)event.getX() + ", " + (int)event.getY() + ")");

		});
		
		// trata mousePressed
		
		
		canvas.setOnMousePressed(event -> {
			if (event.getButton() == MouseButton.PRIMARY) {
				if (primeiraVez == true) {
					if(evento != 0){
					
						x1 = (int)event.getX( );
						y1 = (int)event.getY( );
						PontoGr p1 = new PontoGr(x1, y1, Color.BLUE);
						new PontoGr(x1, y1, Color.BLUE, "", 6).desenharPonto(gc);
					
						/*
						comando[nComando].setX1	  ( x1	);
						comando[nComando].setY1	  ( y1	);
						comando[nComando].setX1	  ( x2	);
						comando[nComando].setY1	  ( y2	);
						comando[nComando].setForma( 'c' );
						
						nComando = nComando + 1;
						*/
						pont.inserirNoFim(p1);
						primeiraVez = false;
				
						
					}
				} else{
					x2 = (int)event.getX();
					y2 = (int)event.getY();
					if(evento ==1){
						double raio = new PontoGr (x1, y1).distance(x2, y2);
						CirculoGr c1 = new CirculoGr(x1, y1, raio, Color.GREEN, "", 2);
						CirculoGr.desenhar(gc, x1, y1, raio, Color.GREEN, "", 2, AlgoritmosCirculos.STROKELINE);
						circ.inserirNoFim(c1);
					}
					if(evento == 2){
						
						RetaGr r1 = new RetaGr(x1, y1, x2, y2, Color.RED, "", 2);
						RetaGr.desenhar(gc, x1, y1, x2, y2, "", Color.RED,  2, AlgoritmosRetas.MIDPOINT);
						
						comando[nComando] = new Comando( x1, y1, x2, y2, 'l' );
						
						/*
						comando[nComando].setX1	  ( x1	);
						comando[nComando].setY1	  ( y1	);
						comando[nComando].setX1	  ( x2	);
						comando[nComando].setY1	  ( y2	);
						comando[nComando].setForma( 'l' );
						*/
						
						nComando = nComando + 1;
						
						reta.inserirNoFim(r1);
					}
					if(evento == 3){
						RetanguloGr re1 = new RetanguloGr(x1, y1, x2, y2, Color.RED);
						re1.desenharQuadrado(gc, x1, y1, x2, y2,Color.RED);
						
						comando[nComando] = new Comando(x1, y1, x2, y2, 'r');
						
						nComando = nComando + 1;
						
						retan.inserirNoFim(re1);
						
					}
					if(evento == 6){
						RetanguloGr re2 = new RetanguloGr(x1, y1, x2, y2, Color.RED);
						re2.desenharQuadrado(gc, x1, y1, x2, y2, Color.RED);
						/*if(re2 != null){
							new Clipping( mapa, circ, reta, retan, re2 );
						}*/ 
					}
					if(evento == 7)
					{
						ctrlZ( comando, canvas, gc );
						criarXML( );
					}
					
					if(evento == 8)
					{
						criarXML( );
					}
					
					PontoGr p2 = new PontoGr(x2, y2, Color.BLUE);
					new PontoGr(x2, y2, Color.BLUE, "", 6).desenharPonto(gc);
					pont.inserirNoFim(p2);
					primeiraVez = true;
				}
			}
		});

		// atributos do painel
		pane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
		pane.setBottom(canvas); // posiciona o componente de desenho
		
		// cria e insere cena
		Scene scene = new Scene(pane);
		palco.setScene(scene);
		palco.show();	
	}
	
	
	
	private void desenharForma(GraphicsContext gc, Ponto inicial,Color r ,Color g)
	{
		//Hexa
		RetaGr.desenhar(gc, inicial.getX(), inicial.getY(), 180 , 155, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 180, 155, 180, 325 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 180, 325, 350, 400 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 350, 400, 520, 325 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 520, 325 , 520, 155 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc,520,155, inicial.getX(), inicial.getY(), "", r, 2, AlgoritmosRetas.MIDPOINT);
		//Retangulo
		RetaGr.desenhar(gc, 180, 155, 520, 155 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 180, 325, 520, 325 , "", r, 2, AlgoritmosRetas.MIDPOINT);
		//X no meio
		RetaGr.desenhar(gc, 180, 155, 520,325, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 180, 325, 520,155, "", r, 2, AlgoritmosRetas.MIDPOINT);
		//trian 1#
		RetaGr.desenhar(gc, inicial.getX(), inicial.getY(), 520 , 325, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, inicial.getX(), inicial.getY(), 180 , 325, "", r, 2, AlgoritmosRetas.MIDPOINT);
		//trian 2#
		RetaGr.desenhar(gc, 180, 155, 350,400, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, 180, 155, 350,400, "", r, 2, AlgoritmosRetas.MIDPOINT);
		//trian 3#
		RetaGr.desenhar(gc,520,155, 350, 400, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc,300,155, 400, 325, "",r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc,400,155, 300, 325, "", r, 2, AlgoritmosRetas.MIDPOINT);
		//reta do meio
		RetaGr.desenhar(gc,240,240,460, 240, "", r, 2, AlgoritmosRetas.MIDPOINT);
		RetaGr.desenhar(gc, inicial.getX(), inicial.getY(), 350 , 400, "", r, 2, AlgoritmosRetas.MIDPOINT);
		//Circulos
		CirculoGr.desenhar(gc, 350, 240, 110, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 240, 240, 105, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 460, 240, 105, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 283, 155, 102, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 420, 155, 102, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 283, 325, 102, g, "", 2, AlgoritmosCirculos.STROKELINE);
		CirculoGr.desenhar(gc, 420, 330, 102, g, "", 2, AlgoritmosCirculos.STROKELINE);
		
	}
	
	public void ctrlZ( Comando[] comandos, Canvas canvas, GraphicsContext gc )
	{
		int nComandoAtual;
		double raio;
		
		gc = canvas.getGraphicsContext2D();
        
		//Limpa a tela
		gc.clearRect( 0, 0, canvas.getWidth( ), canvas.getHeight( ) );
		circ  = null;
		circ  = new ListaLigada( );
        pont  = null;
        pont  = new ListaLigada( );
        reta  = null;
        reta  = new ListaLigada( );
        retan = null;
        retan = new ListaLigada( );
        
        
        //Loop que recriar� cada elemento que foi desenhado, com exce��o do �ltimo
        for( nComandoAtual = 0; nComandoAtual < nComando; nComandoAtual++ )
        {
        	//Se for linha
        	if( comandos[nComandoAtual].getForma( ) == 'l' )
        	{
        		//Desenha linha
        		RetaGr linhaNova = new RetaGr( comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), comandos[nComandoAtual].getX2( ), comandos[nComandoAtual].getY2( ), Color.RED, "", 2 );
        		linhaNova.desenhar(gc, comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), comandos[nComandoAtual].getX2( ), comandos[nComandoAtual].getY2( ), "" , Color.RED, 2, AlgoritmosRetas.MIDPOINT );
        		
        		reta.inserirNoFim( linhaNova );
        	}
        	
        	//Se for ret�ngulo
        	if( comandos[nComandoAtual].getForma( ) == 'r' )
        	{
        		//Desenha ret�ngulo
        		RetanguloGr retanguloNovo = new RetanguloGr( comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), comandos[nComandoAtual].getX2( ), comandos[nComandoAtual].getY2( ), Color.RED );
        		retanguloNovo.desenharQuadrado( gc, comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), comandos[nComandoAtual].getX2( ), comandos[nComandoAtual].getY2( ), Color.RED );
        		
        		retan.inserirNoFim( retanguloNovo );
        	}
        	
        	//Se for c�rculo
        	if( comandos[nComandoAtual].getForma( ) == 'c' )
        	{
        		//Desenha c�rculo
        		raio = new PontoGr( comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ) ).distance( comandos[nComandoAtual].getX2( ), comandos[nComandoAtual].getY2( ) );
        		
        		CirculoGr circuloNovo = new CirculoGr( comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), raio, Color.GREEN, "", 2 );
        		CirculoGr.desenhar(gc, comandos[nComandoAtual].getX1( ), comandos[nComandoAtual].getY1( ), raio, Color.GREEN, "", 2, AlgoritmosCirculos.STROKELINE );
        		
        		circ.inserirNoFim( circuloNovo );
        	}
        
        }
        
        //Apaga o �ltimo elemento a ser criado
        comandos[nComandoAtual] = null;
        
        //Reduz o n�mero total de elementos, j� que o �ltimo foi apagado
        nComando--;
        
    }
	
	public void desenharLinhas(GraphicsContext gc,Ponto inicial ){
			
			int i = 0;
			double auxX, auxY, delta;
			
			double x1,x2;
			double y1,y2;
			
			x1 =  inicial.getX();
			x2 = inicial.getX() + tamLado;
			y1 = inicial.getY();
			y2 = inicial.getY()+ tamLado;
			
			
			if(divisoes == 1){
				
				RetaGr.desenhar(gc,x1, y1,x2 ,y2 , "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
				RetaGr.desenhar(gc,x2, y1,x1 ,y2 , "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
	
				
				
			}else{
				
				delta = tamLado / divisoes;
				
				for(i = 1; i<=divisoes; i++){ // linha baixo
					
					
					auxX = x1 + (delta * (i - 1));
					//auxY = delta * (i - 1) + y1;
					auxY = y2 - (delta * i);
					
					RetaGr.desenhar(gc,auxX, y2,x2 ,auxY, "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
					
				}
				
				for(i = 1; i <= divisoes; i++){ // linha direita
					auxX = x2 - ( delta * i );
					auxY = y2 - (delta * (i - 1));
					
					RetaGr.desenhar(gc,x2, auxY, auxX, y1, "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
				}
				
				for(i = 1; i <= divisoes; i++){// linha cima
					auxX = x2 - ( delta * (i - 1) );
					auxY = y1 + (delta * i);
					
					RetaGr.desenhar(gc,auxX, y1, x1, auxY, "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
				}
				
				for(i = 1; i <= divisoes; i++){// linha esquerdista comunista taxista
					auxX = x1 + ( delta * i );
					auxY = y1 + (delta * (i - 1));
					
					RetaGr.desenhar(gc,x1, auxY, auxX, y2, "", Color.BLUE, 2, AlgoritmosRetas.MIDPOINT);
				}
			}
			
			
		}
	
	
	
	public void criarXML() {
			
			No p;
			CirculoGr gg;
			RetaGr gr;
			RetanguloGr grr;
			int i ;
			
			
			
			try {
				DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
				
				
				Document documentoXML = documentBuilder.newDocument();
				Element root = documentoXML.createElement("root");
				documentoXML.appendChild(root);
				
				if(circ.getInicio() != null){
					Element circulos = documentoXML.createElement("Circulos");
					gg = (CirculoGr) circ.getInicio().getConteudo();
					p = circ.getInicio();
					while(p!= null){
						gg = (CirculoGr) p.getConteudo();
						Attr x1 = documentoXML.createAttribute("x1");
						Attr y1 = documentoXML.createAttribute("y1");
						Attr raio = documentoXML.createAttribute("Raio");
						Attr cor = documentoXML.createAttribute("Cor");
						x1.setValue(""+ gg.getCentro().getx());
						y1.setValue(""+ gg.getCentro().gety());
						cor.setValue("Green");
						raio.setValue(""+ gg.getRaio());
						circulos.setAttributeNode(x1);
						circulos.setAttributeNode(y1);
						circulos.setAttributeNode(cor);
						circulos.setAttributeNode(raio);
						
						p = p.getProx();
						root.appendChild(circulos);
					}
					
				}
				if(reta.getInicio() != null){
					Element retas = documentoXML.createElement("Retas");
					gr = (RetaGr) reta.getInicio().getConteudo();
					p = reta.getInicio();            
					while(p!= null){
						gr = (RetaGr) p.getConteudo();
						Attr x1 = documentoXML.createAttribute("x1");
						Attr y1 = documentoXML.createAttribute("y1");
						Attr x2 = documentoXML.createAttribute("x2");
						Attr y2 = documentoXML.createAttribute("y2");
						Attr cor = documentoXML.createAttribute("Cor");
						x1.setValue(""+ gr.getP1().getx());
						y1.setValue(""+ gr.getP1().gety());
						x2.setValue(""+ gr.getP2().getx());
						y2.setValue(""+ gr.getP2().gety());
						cor.setValue("RED");
						retas.setAttributeNode(x1);
						retas.setAttributeNode(y1);
						retas.setAttributeNode(x2);
						retas.setAttributeNode(y2);
						retas.setAttributeNode(cor);
						p = p.getProx();
						root.appendChild(retas);
					}
					
					
				}
				if(retan.getInicio() != null){
					Element retangulo = documentoXML.createElement("Retangulo");
					grr = (RetanguloGr) retan.getInicio().getConteudo();
					p = retan.getInicio();
					while(p!= null){
						grr = (RetanguloGr) retan.getInicio().getConteudo();
						Attr x1 = documentoXML.createAttribute("x1");
						Attr y1 = documentoXML.createAttribute("y1");
						Attr x2 = documentoXML.createAttribute("x2");
						Attr y2 = documentoXML.createAttribute("y2");
						Attr cor = documentoXML.createAttribute("Cor");
						x1.setValue(""+ grr.getX1());
						y1.setValue(""+ grr.getY1());
						x2.setValue(""+ grr.getX2());
						y2.setValue(""+ grr.getY2());
						cor.setValue("RED");
						retangulo.setAttributeNode(x1);
						retangulo.setAttributeNode(y1);
						retangulo.setAttributeNode(x2);
						retangulo.setAttributeNode(y2);
						retangulo.setAttributeNode(cor);
						p = p.getProx();
						root.appendChild(retangulo);
					}
				
				}
				
				
				
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				
				DOMSource documentFonte = new DOMSource(documentoXML);
				
				StreamResult documentoFinal = new StreamResult(new File("E:\\doc.xml"));
				
				transformer.transform(documentFonte,documentoFinal);
				
				
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			} catch (TransformerConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}



	

}
