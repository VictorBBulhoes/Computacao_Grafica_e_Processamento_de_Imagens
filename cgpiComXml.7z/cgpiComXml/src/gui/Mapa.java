package gui;

import Armazenador.ListaLigada;
import Armazenador.No;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import primitivos.AlgoritmosCirculos;
import primitivos.AlgoritmosRetas;
import primitivos.CirculoGr;
import primitivos.Ponto;
import primitivos.PontoGr;
import primitivos.RetaGr;
import primitivos.RetanguloGr;




public class Mapa {
	
	ListaLigada circulos = null;
	ListaLigada retas = null; 
	ListaLigada retangulo = null;
	
	public Mapa(Stage palco,ListaLigada circ,ListaLigada ret,ListaLigada retan) {
		
		palco.setTitle("Mapeamento");
		
		palco.setWidth(300);
		palco.setHeight(400);
		
		this.circulos = circ;
		this.retas = ret;
		this.retangulo = retan;
		// Painel para os componentes
				BorderPane pane = new BorderPane();

				// componente para desenho
				Canvas canvas = new Canvas(800, 800);
				
				
				// componente para desenhar graficos
				GraphicsContext gcg ;
				
				
				
				
				gcg = canvas.getGraphicsContext2D();
				
				redesenhar(gcg);
				
				
		
		// atributos do painel
				pane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
				pane.setBottom(canvas); // posiciona o componente de desenho

				// cria e insere cena
				Scene scene = new Scene(pane);
				palco.setScene(scene);
				palco.show();	
		
		
	}
	
public void redesenhar(GraphicsContext gc){
		
		No p;
		CirculoGr gg;
		RetaGr gr;
		RetanguloGr grr;
		if(circulos != null){
			gg = (CirculoGr) circulos.getInicio().getConteudo();
			p = circulos.getInicio();
			while(p!= null){
				gg = (CirculoGr) p.getConteudo();
				gg.desenhar(gc,(gg.getCentro().getx()*0.375),(gg.getCentro().gety()*0.5),(gg.getRaio()*0.375),Color.GREEN,"", 2, AlgoritmosCirculos.STROKELINE);
				
				p = p.getProx();
			}
		}
		if(retas != null){
			gr = (RetaGr) retas.getInicio().getConteudo();
			p = retas.getInicio();
			while(p!= null){
				gr = (RetaGr) p.getConteudo();
				gr.desenhar(gc, (gr.getP1().getx()*0.375),(gr.getP1().getx()*0.375),(gr.getP2().getx()*0.375),(gr.getP2().gety()*0.375), "",Color.RED, 2, AlgoritmosRetas.MIDPOINT);
				
				p = p.getProx();
			}
		}
		if(retangulo != null){
			grr = (RetanguloGr) retangulo.getInicio().getConteudo();
			p = retangulo.getInicio();
			while(p!= null){
				grr = (RetanguloGr) p.getConteudo();
				grr.desenharQuadrado(gc,(grr.getX1()*0.375),(grr.getY1()*0.375),(grr.getX2()*0.375),(grr.getY2()*0.375),Color.RED);
				
				p = p.getProx();
			}
		}
		
		
	}

	
	
}
