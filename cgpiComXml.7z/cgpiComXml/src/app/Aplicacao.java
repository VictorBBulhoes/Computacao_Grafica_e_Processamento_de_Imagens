package app;


import gui.RetaComMouseGui;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * @author Breno Amaral, Gabrielle Ramos, Gustavo Gon�alves & Victor Bulh�es
 * @version v1.0 2019/11/11
 */

public class Aplicacao extends Application{
     public static void main (String args[]) {
        launch(args);
    }

    @Override
    public void start(Stage palco) throws Exception {
        new RetaComMouseGui(palco);
    }
}
