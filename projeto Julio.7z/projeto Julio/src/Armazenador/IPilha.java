package Armazenador;




/**
 * Escreva a descri��o da interface PFArmazenador aqui.
 * 
 * @author (seu nome) 
 * @version (n�mero da vers�o ou data)
 */

public interface IPilha
{
    
    public void push(Object v);
     public Object pop();
}
