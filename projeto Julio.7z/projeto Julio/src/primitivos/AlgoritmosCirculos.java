package primitivos;

public enum AlgoritmosCirculos{
	DEFAULT, POLAR, MIDPOINT, STROKELINE
}